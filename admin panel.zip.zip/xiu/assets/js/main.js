/**
 * @author Ese curtis 
 * @copyright Dragon Programming Language
 * @description The Implementation of custom and inbuilt functions for the dragon language admin panel
 */


document.body.onload = ()=>{

    /**
     * @description Page loader
     */
    setTimeout(() => {
        document.body.classList.remove("unloaded");
        document.body.classList.add("loaded");
    }, 600);

    /**
     * @description Making the togglers functional [header navigation]
     */
    el("#open-head-nav")[0]?.addEventListener("click", ()=>{
        element.show(".header-nav");
    });
    el("#close-head-nav")[0]?.addEventListener("click", ()=>{
        element.hide(".header-nav");
    });
    
    /**
     * @description Making the togglers functional [sidebar]
     */
    el("#side-bar-toggler")[0]?.addEventListener("click", ()=>{
        if(document.body.clientWidth <= 630){
            el(".dgn-side-bar")[0].classList.toggle("active");
            el("#side-bar-toggler")[0].classList.toggle("active");
        }
    });

    /**
     * @description Making the togglers functional [Modal]
     */
    el(".modal-close")[0]?.addEventListener("click", modal.close);

    /**
     * @description Hiding the header bar for responsiveness
     */
    el("body")[0].onscroll = ()=>{
        if(el("header")[0]){
            if(scrollY > el("header")[0]?.scrollHeight){
                el("header")[0].style.opacity = "0";
            }else{
                el("header")[0].style.opacity = "100";
            }
        }
    }
}
