

/**
 * @author Ese curtis 
 * @copyright Dragon Programming Language
 * @description The main custom functions behind the dragon language admin panel
 */


 /**
 * @description Refrecncing an element
 */
const el = refElement=>{
    return document.querySelectorAll(refElement);
}

 /**
 * @description Used to manipulate an element
 */
const element = {
    show : (refElement, transform = "translateX(0vw)")=>{
        el(refElement)[0].style.transform = transform;
        el(refElement)[0].style.opacity = 100;
    },
    hide : refElement=>{
        el(refElement)[0].style.opacity = 0;
        el(refElement)[0].style.transform = "translateX(100vw)";
    },
    dissolve : refElement=>{
        el(refElement)[0].style.opacity = 0;
        setTimeout(() => {
            el(refElement)[0].style.display = "none";
        }, 500);
    },
    solve : (refElement, displayStyle = "flex")=>{
        el(refElement)[0].style.display = displayStyle;
        setTimeout(() => {
            el(refElement)[0].style.opacity = 100;   
        }, 500);
    }
}

 /**
 * @description Used to create a simple modal
 */
const modal =  {
    open: content=>{
        element.solve(".modal");
        el(".modal-content")[0].innerHTML = content;
    },
    close: ()=>{
        element.dissolve(".modal");
        el(".modal-content")[0].innerHTML = "{content}";
    }
}

 /**
 * @description Used to create a simple toast
 */
const toast = (content, timeout = 1000)=>{
    modal.open(content);
    setTimeout(() => {
        modal.close();
    }, timeout);
}

